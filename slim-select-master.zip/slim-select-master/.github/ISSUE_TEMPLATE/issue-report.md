---
name: Issue Report
about: Create a report to help me improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the issue is.

**Screenshots**
Add screenshots to help explain your issue. If you do not submit at least an image or animated gif I most likely wont look into it.
